package quiz20;

import java.util.LinkedList;
import java.util.List;

public class FileQuiz03 {
	
	public static void main(String[] args) {
		
		/*
		 * 상혁이가 입사한 회사에서 매일 오전 아침 7시에 연계사(회사)에서
		 * 날짜유형의 CSV파일을 매일 전송 해준다
		 * 
		 * ex) 2024_06_24_data.csv
		 * 주의할 점은 내일이 되면 2024_06_05_data.csv가 된다
		 * 
		 * 그래서 상혁이는 아침마다 csv파일을 읽어서 
		 * 우리의 데이터베이스에 저장하는 프로그램 코드를 생성해야 한다
		 * 
		 * 1. buffered를 사용해서 오늘 날짜패턴_data.csv 파일을 읽어서 한 줄에 하나씩 출력을 해라
		 * 2. 읽은 데이터는 (,)구분자로 만들어져 있는데 콤마(,)기준으로 데이터를 분리해서
		 * 	  getter, setter를 가지는 Data클래스에 저장하고, 이 객체를 리스트에 저장하면 된다
		 * 
		 * 힌트) Data사용, Data객체는 본인이 생성, ArrayList사용
		 */
		
		List<Integer> list = new LinkedList<>();
		
//		String str = s.split("");
		
		
		
	}

}
