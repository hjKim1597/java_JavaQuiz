package quiz21;

public class RegexQuiz02 {

	public static void main(String[] args) {
		
		String str = "123123-45644 GS25(치킨도시락) 4,400원";
		String str2 = "123123-3453454 GS25(마늘햄쌈) 5,000원";
		String str3 = "123456-3453 GS(갓혜자도시락) 6,000";
		
		String[] arr = {str, str2, str3};
		
		//arr 상품번호, GS25, (상품명), 가격 을 정규표현식으로 나눠서 출력.
		
		
		
		
		
		
		
		

	}
}
